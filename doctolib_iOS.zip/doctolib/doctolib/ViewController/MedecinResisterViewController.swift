//
//  MedecinResisterViewController.swift
//  doctolib
//
//  Created by Moussa Toure on 03/12/2018.
//  Copyright © 2018 Moussa Toure. All rights reserved.
//

import UIKit
import SQLite
import SQLite3


class MedecinResisterViewController: UIViewController {
    @IBOutlet weak var medTitleLabel: UILabel!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var profilTextField: UITextField!
    @IBOutlet weak var nomTextField: UITextField!
    @IBOutlet weak var prenomTextField: UITextField!
    @IBOutlet weak var adresseTextField: UITextField!
    @IBOutlet weak var specialiteTextField: UITextField!
    @IBOutlet weak var telephoneTextField: UITextField!
    
    private var medecins = [Medecin]()
    private var selectedMedecin: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func validerButtonClicked(_ sender: Any) {
         let email = emailTextField.text ?? ""
         let motDePasse = passwordTextField.text ?? ""
         let profil = profilTextField.text ?? ""
         let nom = nomTextField.text ?? ""
         let prenom = prenomTextField.text ?? ""
         let adresse = adresseTextField.text ?? ""
         let specialite = specialiteTextField.text ?? ""
         let telephone = telephoneTextField.text ?? ""
        
// Verification de la validité des données saisies
        if(email.isEmpty || motDePasse.isEmpty || profil.isEmpty || nom.isEmpty || prenom.isEmpty || adresse.isEmpty || specialite.isEmpty || telephone.isEmpty  ){
            displayMyAlertMessage(userMessage: "Vous devez remplir tous les champs")
            return;
        }
// insertion des données médecin dans la base de données
        if let id = DoctolibDB.instance.addMedecin(memail: email, mmotDePasse: motDePasse, mprofil: profil, mnom: nom, mprenom: prenom, madresse: adresse, mspecialite: specialite, mtelephone: telephone){
            let medecin = Medecin(id: id, email: email, motDePasse: motDePasse, profil:profil, nom: nom, prenom: prenom, adresse: adresse, specialite: specialite, telephone: telephone)
            
            medecins.append(medecin)
            
// affichage d'alerte de confirmation d'inscription
            let myAlert = UIAlertController(title: "Alerte", message: "Vous êtes bien inscrit en tant qu médecin. Vos données sont disponibles et supprimables à la demande. Merci", preferredStyle: UIAlertControllerStyle.alert )
            let okAction = UIAlertAction(title: "ok", style: UIAlertActionStyle.default){
                ACTION in self.dismiss(animated: true, completion: nil)
            }
            myAlert.addAction(okAction)
            self.present(myAlert, animated: true, completion: nil)
            
            print("Medecin inscrit avec succcès")
    }
   
    }
    
//fonction pour l'affichage des erreurs dans le formulaire
    func displayMyAlertMessage(userMessage: String){
        let myAlert = UIAlertController(title: "Alerte", message: userMessage, preferredStyle: UIAlertControllerStyle.alert )
        let okAction = UIAlertAction(title: "ok", style: UIAlertActionStyle.default, handler: nil)
       
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
        
        
    }
        /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
