//
//  LoginViewController.swift
//  doctolib
//
//  Created by Moussa Toure on 03/12/2019.
//  Copyright © 2018 Moussa Toure. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var segment: UISegmentedControl!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
  
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//Choix du profil de l'utilisateur
    @IBAction func profilSelected(_ sender: UISegmentedControl) {
         var profil: Bool
        
        if segment.selectedSegmentIndex == 0 {
            profil = true
        }else if segment.selectedSegmentIndex == 1{
            profil = false
        }
    }
    
    @IBAction func connectButtonClicked(_ sender: Any) {
        let email = emailTextField.text ?? ""
        let motDePasse = passwordTextField.text ?? ""
        
        var medecins = [Medecin]()
        var patients = [Patient]()
         /*
        let storedemail = medecins.filter(email)
        let storedpassword = medecins.filter(medecins)
        
        if (email == storedemail){
            if (motDePasse == storedpassword){
                
            }
        }
         
        }
    
    //let medEmail = medecins.filter(email == memail)
         */
        //Verification si les champs sont remplis en intégralité
        
        if(email.isEmpty || motDePasse.isEmpty ){
            displayMyAlertMessage(userMessage: "Vous devez taper vos identifiants")
            return;
        }
        
    }
    
    // Fonction affichant une alerte d'erreur dans le formulaire
    func displayMyAlertMessage(userMessage: String){
        let myAlert = UIAlertController(title: "Alerte", message: userMessage, preferredStyle: UIAlertControllerStyle.alert )
        let okAction = UIAlertAction(title: "ok", style: UIAlertActionStyle.default, handler: nil)
        
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
