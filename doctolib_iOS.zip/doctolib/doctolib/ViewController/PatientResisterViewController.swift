//
//  PatientResisterViewController.swift
//  doctolib
//
//  Created by Moussa Toure on 03/12/2018.
//  Copyright © 2018 Moussa Toure. All rights reserved.
//

import UIKit
import SQLite
import SQLite3

class PatientResisterViewController: UIViewController {
    
    @IBOutlet weak var patientTitleLabel: UILabel!
    @IBOutlet weak var numSSTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var profilTextField: UITextField!
    @IBOutlet weak var nomTetxField: UITextField!
    @IBOutlet weak var prenomTextField: UITextField!
    @IBOutlet weak var adresseTextField: UITextField!
    @IBOutlet weak var telephoneTextField: UITextField!
    
    private var patients = [Patient]()
    private var selectedPatient: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
// Fonction de gestion du boutton valider pour traiter le formulaire
    
    @IBAction func validerButtonClicked(_ sender: Any) {
        let numSS = numSSTextField.text ?? ""
        let email = emailTextField.text ?? ""
        let motDePasse = passwordTextField.text ?? ""
        let profil = profilTextField.text ?? ""
        let nom = nomTetxField.text ?? ""
        let prenom = prenomTextField.text ?? ""
        let adresse = adresseTextField.text ?? ""
        let telephone = telephoneTextField.text ?? ""
        
//Verification si les champs sont remplis en intégralité
        
        if(numSS.isEmpty || email.isEmpty || motDePasse.isEmpty || profil.isEmpty || nom.isEmpty || prenom.isEmpty || adresse.isEmpty || telephone.isEmpty  ){
            displayMyAlertMessage(userMessage: "Vous devez remplir tous les champs")
            return;
        }
//Insertion des données patient dans la base
        
        if let id = DoctolibDB.instance.addPatient(pnumSS: numSS, pemail: email, pmotDePasse: motDePasse, pprofil: profil, pnom: nom, pprenom: prenom, padresse: adresse, ptelephone: telephone){
           
            let patient = Patient(id: id, numSS: numSS, email: email, motDePasse: motDePasse, profil:profil, nom: nom, prenom: prenom, adresse: adresse, telephone: telephone)
            
            patients.append(patient)
            
//message de confirmation d'inscription de patient
            
            let myAlert = UIAlertController(title: "Alerte", message: "Vous êtes bien inscrit en tant que patient. Vos données sont disponibles et supprimables à la demande. Merci", preferredStyle: UIAlertControllerStyle.alert )
            let okAction = UIAlertAction(title: "ok", style: UIAlertActionStyle.default){
                ACTION in self.dismiss(animated: true, completion: nil)
            }
            myAlert.addAction(okAction)
            self.present(myAlert, animated: true, completion: nil)
            
            print("Patient inscrit avec succcès")
        }
    }
    
// Fonction affichant une alerte d'erreur dans le formulaire
    func displayMyAlertMessage(userMessage: String){
        let myAlert = UIAlertController(title: "Alerte", message: userMessage, preferredStyle: UIAlertControllerStyle.alert )
        let okAction = UIAlertAction(title: "ok", style: UIAlertActionStyle.default, handler: nil)
        
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
