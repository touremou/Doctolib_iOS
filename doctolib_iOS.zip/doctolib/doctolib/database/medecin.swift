//
//  medecin.swift
//  doctolib
//
//  Created by Moussa Toure on 13/12/2018.
//  Copyright © 2018 Moussa Toure. All rights reserved.
//

import Foundation

class Medecin {
    
    let id: Int64?
    var email: String
    var motDePasse: String
    var profil: String
    var nom: String
    var prenom: String
    var adresse: String
    var specialite: String
    var telephone: String
    
    init(id: Int64) {
        self.id = id
        email = ""
        motDePasse = ""
        profil = ""
        nom = ""
        prenom = ""
        adresse = ""
        specialite = ""
        telephone = ""
        
    }
    
    init(id: Int64, email: String, motDePasse: String,  profil: String, nom: String, prenom: String, adresse: String,  specialite: String,  telephone: String) {
        self.id = id
        self.email = email
        self.motDePasse = motDePasse
        self.profil = profil
        self.nom = nom
        self.prenom = prenom
        self.adresse=adresse
        self.specialite = specialite
        self.telephone = telephone
        
    }
    
    
}
