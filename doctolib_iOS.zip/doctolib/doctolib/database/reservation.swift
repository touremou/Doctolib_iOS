//
//  reservation.swift
//  doctolib
//
//  Created by Moussa Toure on 13/12/2018.
//  Copyright © 2018 Moussa Toure. All rights reserved.
//

import Foundation
class Reservation {
    
    let id: Int64?
    var motif: String

    
    init(id: Int64) {
        self.id = id
        motif = ""
        
    }
    
    init(id: Int64, motif: String) {
        self.id = id
        self.motif = motif
        
    }
    
}
