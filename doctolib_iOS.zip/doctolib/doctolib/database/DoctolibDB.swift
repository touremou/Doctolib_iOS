//
//  DoctolibDB.swift
//  doctolib
//
//  Created by Moussa Toure on 13/12/2018.
//  Copyright © 2018 Moussa Toure. All rights reserved.
//

import SQLite
/*
 // MARK: - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
 // Get the new view controller using segue.destinationViewController.
 // Pass the selected object to the new view controller.
 }
 */
class DoctolibDB {
 
// Déclaration des attributs des tables de la base données
    
    private let medecin = Table("medecin")
    private let patient = Table("patient")
    private let disponibilite = Table("disponibilite")
    private let reservation = Table("reservation")
    
    private let id = Expression<Int64>("id")
    private let email = Expression<String?>("email")
    private let motDePasse = Expression<String?>("motDePasse")
    private let profil = Expression<String?>("profil")
    private let nom = Expression<String?>("nom")
    private let prenom = Expression<String?>("prenom")
    private let adresse = Expression<String>("adresse")
    private let specialite = Expression<String?>("specialite")
    private let telephone = Expression<String>("telephone")
    
    private let numSS = Expression<String>("numSS")
    
    private let jour = Expression<String>("jour")
    private let heureDebut = Expression<String>("heureDebut")
    private let heureFin = Expression<String>("heureFin")
    
    private let motif = Expression<String>("motif")
    
    static let instance = DoctolibDB()
    private let db: Connection?
    
//Connexcion à la base de données
    private init() {
        let path = NSSearchPathForDirectoriesInDomains(
            .documentDirectory, .userDomainMask, true
            ).first!
        
        do {
            db = try Connection("\(path)/Doctolib.sqlite3")
            createTable()
        } catch {
            db = nil
            print ("Base de données disponible")
        }
    }
// fonction permettant de créer les tables de la base de données
    
    func createTable() {

//Table médecin
        do {
            try db!.run(medecin.create(ifNotExists: true) { table in
                table.column(id, primaryKey: true)
                table.column(email, unique: true)
                table.column(motDePasse, unique: true)
                table.column(profil)
                table.column(nom)
                table.column(prenom)
                table.column(adresse)
                table.column(specialite)
                table.column(telephone, unique: true)
            })
        } catch {
            print("Création de la table medecin disponible")
        }
        
 //Table patient
        do {
            try db!.run(patient.create(ifNotExists: true) { table in
                table.column(id, primaryKey: true)
                table.column(numSS, unique: true)
                table.column(email, unique: true)
                table.column(motDePasse, unique: true)
                table.column(profil)
                table.column(nom)
                table.column(prenom)
                table.column(adresse)
                table.column(telephone, unique: true)
            })
        } catch {
            print("Création de la table patient disponible")
        }

//Table disponibilité
        do {
            try db!.run(disponibilite.create(ifNotExists: true) { table in
                table.column(id, primaryKey: true)
                table.column(jour)
                table.column(heureDebut)
                table.column(heureFin)
            })
        } catch {
            print("Création de la table disponibilité disponible")
        }
        
//Table reservation
        do {
            try db!.run(reservation.create(ifNotExists: true) { table in
                table.column(id, primaryKey: true)
                table.column(motif)
            })
        } catch {
            print("Création de la table reservation disponible")
        }
    }
    
//Fonctions permettant d'ajouer des données dans la base grâce à une requête
    func addMedecin(memail: String, mmotDePasse: String, mprofil: String, mnom: String, mprenom: String, madresse: String, mspecialite: String, mtelephone: String) -> Int64? {
        do {
            let insert = medecin.insert(email <- memail, motDePasse <- mmotDePasse, profil <- mprofil, nom <- mnom, prenom <- mprenom, adresse <- madresse, specialite <- mspecialite, telephone <- mtelephone)
            let id = try db!.run(insert)
            
            return id
        } catch {
            print("Insertion dans la table medecin à échoué")
            return nil
        }
    }
    func addPatient(pnumSS: String, pemail: String, pmotDePasse: String, pprofil: String, pnom: String, pprenom: String, padresse: String, ptelephone: String) -> Int64? {
            do {
                let insert = patient.insert(numSS <- pnumSS, email <- pemail, motDePasse <- pmotDePasse, profil <- pprofil, nom <- pnom, prenom <- pprenom, adresse <- padresse, telephone <- ptelephone)
                let id = try db!.run(insert)
                
                return id
            } catch {
                print("Insertion dans la table patient à échoué")
                return nil
            }
        
    }
        
        func addDisponibilite(djour: String, dheureDebut: String, dheureFin: String) -> Int64? {
            do {
                let insert = disponibilite.insert(jour <- djour, heureDebut <- dheureDebut, heureFin <- dheureFin)
                let id = try db!.run(insert)
                
                return id
            } catch {
                print("Insertion dans la table disponibilité à échoué")
                return nil
            }
    }
            
    func addReservation(rmotif: String) -> Int64? {
                do {
                    let insert = reservation.insert(motif <- rmotif)
                    let id = try db!.run(insert)
                    
                    return id
                } catch {
                    print("Insertion dans la table reservation à échoué")
                    return nil
                }
    
}
 /*
  // fonction qui recupère les medecins recherché par le patient
    func getMedecins() -> [Medecin] {
        var medecins = [Medecin]()
        
        do {
            for medecin in try db!.prepare(self.medecin) {
                medecins.append(Medecin(
                    id: medecin[id],
                    email: medecin[email]!,
                    nom: medecin[nom],
                    prenom: medecin[prenom],
                    adresse: medecin[adresse],
                    specialite: medecin[specialite],
                    telephone: medecin[telephone]
                ))
            }
        } catch {
            print("Select a échoué")
        }
        
        return medecins
    }
     
   */
     
 
    func getDisponiilite() -> [Disponibilite] {
        var disponibilites = [Disponibilite]()
        
        do {
            for disponibilite in try db!.prepare(self.disponibilite) {
                disponibilites.append(Disponibilite(
                    id: disponibilite[id],
                    jour: disponibilite[jour],
                    heureDebut: disponibilite[heureDebut],
                    heureFin: disponibilite[heureFin]
                ))
            }
        } catch {
            print("Select a échoué")
        }
        
        return disponibilites
    }
    
    func getReservation() -> [Reservation] {
        var reservations = [Reservation]()
        
        do {
            for reservation in try db!.prepare(self.reservation) {
                reservations.append(Reservation(
                    id: reservation[id],
                    motif: reservation[motif]
                ))
            }
        } catch {
            print("Select a échoué")
        }
        
        return reservations
    }
}

