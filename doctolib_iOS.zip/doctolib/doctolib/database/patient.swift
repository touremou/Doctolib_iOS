//
//  patient.swift
//  doctolib
//
//  Created by Moussa Toure on 13/12/2018.
//  Copyright © 2018 Moussa Toure. All rights reserved.
//

import Foundation
class Patient {
    
    let id: Int64?
    var numSS: String
    var email: String
    var motDePasse: String
    var profil: String
    var nom: String
    var prenom: String
    var adresse: String
    var telephone: String
    
    init(id: Int64) {
        self.id = id
        numSS = ""
        email = ""
        motDePasse = ""
        profil = ""
        nom = ""
        prenom = ""
        adresse = ""
        telephone = ""
        
    }
    
    init(id: Int64, numSS: String, email: String, motDePasse: String,  profil: String, nom: String, prenom: String, adresse: String,  telephone: String) {
        self.id = id
        self.numSS = numSS
        self.email = email
        self.motDePasse = motDePasse
        self.profil = profil
        self.nom = nom
        self.prenom = prenom
        self.adresse=adresse
        self.telephone = telephone
    
}
}
