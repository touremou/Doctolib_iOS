//
//  disponibilite.swift
//  doctolib
//
//  Created by Moussa Toure on 13/12/2018.
//  Copyright © 2018 Moussa Toure. All rights reserved.
//

import Foundation
class Disponibilite {
    
    let id: Int64?
    var jour: String
    var heureDebut: String
    var heureFin: String
    
    
    init(id: Int64) {
        self.id = id
        jour = ""
        heureDebut = ""
        heureFin = ""
        
        
    }
    
    init(id: Int64, jour: String, heureDebut: String,  heureFin: String) {
        self.id = id
        self.jour = jour
        self.heureDebut = heureDebut
        self.heureFin = heureFin
        
    }
    
}
